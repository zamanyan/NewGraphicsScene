#ifndef CUSTOMWIDGETS_H
#define CUSTOMWIDGETS_H
#include "Types.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QDockWidget>
#include <QLabel>
#include <QIcon>
#include <QGraphicsScene>
#include <QGraphicsView>

namespace Layer {
    class LayerCell : public QWidget {

        Q_OBJECT

    public:
        LayerCell(const QString& lbl_text,
                  const QString& icon_absolute_path,
                  LayerType layerType,
                  QWidget *parent = nullptr,
                  Qt::WindowFlags f = Qt::WindowFlags())
            : QWidget(parent, f), m_layerType(layerType)
        {
            m_button= new QPushButton(this);
            m_button->setAutoDefault(true);
            m_label = new QLabel(lbl_text, this);

            QPixmap pixmap(icon_absolute_path);
            QIcon ButtonIcon(pixmap);
            m_button->setIcon(ButtonIcon);
            m_button->setIconSize(pixmap.rect().size());

            m_button->setFixedSize(ButtonIcon.actualSize(ButtonIcon.availableSizes().first()));//never larger than ic.availableSizes().first()
            m_button->setIcon(ButtonIcon);
            m_button->setIconSize(ButtonIcon.availableSizes().first());

            auto layout = new QHBoxLayout(this);
            layout->addWidget(m_button);
            layout->addWidget(m_label);
            connect(m_button, SIGNAL(clicked()),
                    this, SLOT(sendLayerType()));
        }
        virtual ~LayerCell() {}

    signals:
        void sendSignalLT(LayerType); // send signal for LayerType

    public slots:
        void sendLayerType() {
            emit sendSignalLT(m_layerType);
        }

    private:
        QPushButton * m_button;
        QLabel * m_label;
        LayerType m_layerType;
    };
}

//----------------------------------------------------------------------------------------------------

namespace Shapes {
    class Shape : public QWidget {

        Q_OBJECT

    public:
        Shape(const QString& icon_absolute_path,
              ShapeType shapeType,
              QWidget *parent = nullptr,
              Qt::WindowFlags f = Qt::WindowFlags())
            : QWidget(parent, f), m_shapeType(shapeType)
        {
            m_button= new QPushButton(this);
            m_button->setAutoDefault(true);

            QPixmap pixmap(icon_absolute_path);
            QIcon ButtonIcon(pixmap);
            /*
            m_button->setIcon(ButtonIcon);
            m_button->setIconSize(pixmap.rect().size());
            */

            m_button->setFixedSize(ButtonIcon.actualSize(ButtonIcon.availableSizes().first()));
            m_button->setIcon(ButtonIcon);
            m_button->setIconSize(ButtonIcon.availableSizes().first());

            auto layout = new QHBoxLayout(this);
            layout->addWidget(m_button);
            connect(m_button, SIGNAL(clicked()),
                    this, SLOT(sendShapeType()));
        }
        virtual ~Shape() {}

    signals:
        void sendSignalSHT(ShapeType);

    public slots:
        void sendShapeType() {
            emit sendSignalSHT(m_shapeType);
        }

    private:
        QPushButton * m_button;
        ShapeType m_shapeType;
    };
}

#endif // CUSTOMWIDGETS_H
