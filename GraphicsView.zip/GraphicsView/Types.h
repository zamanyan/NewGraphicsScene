#ifndef TYPES_H
#define TYPES_H

namespace Layer {
    enum LayerType {
        M1,
        M2,
        M3,
        M4,
        M5,
    };
}

namespace Shapes {
    enum ShapeType {
        Line,
        Rectangle,
        Circle,
        Polygon,
        Path
    };
}

#endif // TYPES_H


