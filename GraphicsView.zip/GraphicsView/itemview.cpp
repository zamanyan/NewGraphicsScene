#include "itemview.h"
#include "math.h"
#include "utilities.h"

#include <iostream>

#include <QMouseEvent>
#include <QPainter>
#include <QPointF>
#include <QPixmap>
#include <QtMath>
#include <QLine>

ItemView::ItemView() : m_firstClick(false),
                       m_readyToDraw(false),
                       m_mouseIsClicked(false),
                       m_currentItem(nullptr),
                       m_pathLine(nullptr)

{
    scene = new QGraphicsScene(this);
    scene->setSceneRect(QRectF(0, 0, 4000, 4000));
    setScene(scene);
    createBackground();
    setMouseTracking(true);
}

void ItemView::createBackground()
{
    QPixmap* b_pixmap = new QPixmap(QSize(4000, 4000));
    b_pixmap->fill(Qt::black);
    QPainter* painter = new QPainter(b_pixmap);
    painter->setPen(QPen(Qt::white, Qt::SolidLine));
    for(int i = -1000; i < 1000; ++i) {
        for(int j = -1000; j < 1000; ++j) {
            painter->drawPoint(i * 10, j * 10);
        }
    }
    painter->drawLine(QLineF(QPointF(0, 2000), QPointF(4000, 2000)));
    painter->drawLine(QLineF(QPointF(2000, 0), QPointF(2000, 4000)));
    QBrush brush(*b_pixmap);
    setBackgroundBrush(brush);
}

QPoint* ItemView::mapToBackground(QPoint point)
{
    int x = point.x() / 10;
    int y = point.y() / 10;
    if (10 * x + 10 - point.x() < point.x() - 10 * x) {
      x++;
    }
    if (fabs(10 * y + 10 - point.y()) < fabs(point.y() - 10 * y)) {
      y++;
    }
    return new QPoint(x * 10, y * 10);
}

void ItemView::recieveLayerType(Layer::LayerType layerType)
{
    m_layerType = layerType;
}

void ItemView::recieveShapeType(Shapes::ShapeType shapeType)
{
    m_shapeType = shapeType;
}

//------------------Mouse event for shapes------------------

void ItemView::mousePressEvent(QMouseEvent* event)
{
    switch (m_shapeType) {
        case Shapes::ShapeType::Rectangle :
            rectangleMousePressEvent(event);
            break;
        case Shapes::ShapeType::Line :
            lineMousePressEvent(event);
            break;
        case Shapes::ShapeType::Circle :
            circleMousePressEvent(event);
            break;
        case Shapes::ShapeType::Polygon :
            polygonMousePressEvent(event);
            break;
        case Shapes::ShapeType::Path :
            pathMousePressEvent(event);
            break;
    }
    QGraphicsView::mousePressEvent(event);
}

void ItemView::mouseReleaseEvent(QMouseEvent* event)
{
    switch (m_shapeType) {
        case Shapes::ShapeType::Rectangle :
            rectangleMouseReleaseEvent(event);
            break;
        case Shapes::ShapeType::Line :
            lineMouseReleaseEvent(event);
            break;
        case Shapes::ShapeType::Circle :
            circleMouseReleaseEvent(event);
            break;
        case Shapes::ShapeType::Polygon :
            polygonMouseReleaseEvent(event);
            break;
        case Shapes::ShapeType::Path :
            pathMouseReleaseEvent(event);
            break;
    }
    QGraphicsView::mouseReleaseEvent(event);
}

void ItemView::mouseMoveEvent(QMouseEvent* event)
{
    switch (m_shapeType) {
        case Shapes::ShapeType::Rectangle :
            rectangleMouseMoveEvent(event);
            break;
        case Shapes::ShapeType::Line :
            lineMouseMoveEvent(event);
            break;
        case Shapes::ShapeType::Circle :
            circleMouseMoveEvent(event);
            break;
        case Shapes::ShapeType::Polygon :
            polygonMouseMoveEvent(event);
            break;
        case Shapes::ShapeType::Path :
            pathMouseMoveEvent(event);
            break;
    }
    QGraphicsView::mouseMoveEvent(event);
}

void ItemView::mouseDoubleClickEvent(QMouseEvent* event)
{
    if (m_shapeType == Shapes::ShapeType::Polygon) {
        polygonMouseDoubleClickEvent();
    }
    else if (m_shapeType == Shapes::ShapeType::Path) {
        pathMouseDoubleClickEvent(event);
    }
    QGraphicsView::mouseDoubleClickEvent(event);
}

//------------------Functions to draw a RECTANGLE------------------

void ItemView::rectangleMousePressEvent(QMouseEvent* event)
{
    m_pressedPos = event->pos();
}

void ItemView::rectangleMouseReleaseEvent(QMouseEvent* event)
{
    m_releasedPos = event->pos();
    if (m_pressedPos == m_releasedPos) {
        m_firstClick = !m_firstClick;
        if (m_firstClick) {
            m_point1 = mapToScene(event->pos());
            m_tempPoint = m_point1;
        }
        else {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            m_point2 = mapToScene(event->pos());
            rectDrawingDirection();
            m_rectangle = add_Rectangle();
            m_rectangle->setFlag(QGraphicsItem::ItemIsMovable);
        }
        m_readyToDraw = !m_readyToDraw;
    }
}

void ItemView::rectangleMouseMoveEvent(QMouseEvent* event)
{
    if (m_readyToDraw) {
        if (m_currentItem) {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
        }
        m_point2 = mapToScene(event->pos());
        rectDrawingDirection();
        m_currentItem = add_Rectangle();
    }
}

void ItemView::rectDrawingDirection()
{
    if (m_point2.x() < m_tempPoint.x() && m_point2.y() < m_tempPoint.y()) {
        m_point1 = m_point2;
        m_point2 = m_tempPoint;
    }
    else if (m_point2.x() < m_tempPoint.x() && m_point2.y() > m_tempPoint.y()) {
        m_point1 = QPointF(m_tempPoint.x() - (m_tempPoint.x() - m_point2.x()),
                           m_tempPoint.y());
        m_point2 = QPointF(m_tempPoint.x(),
                           m_tempPoint.y() + (m_point2.y() - m_tempPoint.y()));
    }
    else if (m_point2.x() > m_tempPoint.x() && m_point2.y() < m_tempPoint.y()) {
        m_point1 = QPointF(m_tempPoint.x(),
                           m_tempPoint.y() - (m_tempPoint.y() - m_point2.y()));
        m_point2 = QPointF(m_tempPoint.x() + (m_point2.x() - m_tempPoint.x()),
                           m_tempPoint.y());
    }
}

QGraphicsRectItem* ItemView::add_Rectangle()
{
    QGraphicsRectItem* rect = new QGraphicsRectItem;
    switch(m_layerType) {
    case Layer::LayerType::M1 :
        rect = scene->addRect(QRectF(m_point1, m_point2),
                              QPen(Qt::blue, 2),
                              QBrush(Qt::blue, Qt::BDiagPattern));
        break;
    case Layer::LayerType::M2 :
        rect = scene->addRect(QRectF(m_point1, m_point2),
                              QPen(Qt::green, 2),
                              QBrush(Qt::green, Qt::Dense7Pattern));
        break;
    case Layer::LayerType::M3 :
        rect = scene->addRect(QRectF(m_point1, m_point2),
                              QPen(Qt::red, 2),
                              QBrush(Qt::red, Qt::FDiagPattern));
        break;
    case Layer::LayerType::M4 :
        rect = scene->addRect(QRectF(m_point1, m_point2),
                              QPen(Qt::cyan, 2),
                              QBrush(Qt::cyan, Qt::DiagCrossPattern));
        break;
    case Layer::LayerType::M5 :
        rect = scene->addRect(QRectF(m_point1, m_point2),
                              QPen(Qt::magenta, 2),
                              QBrush(Qt::magenta, Qt::Dense5Pattern));
        break;
    }
    return rect;
}

//------------------Functions to draw a LINE------------------

void ItemView::lineMousePressEvent(QMouseEvent* event)
{
    m_pressedPos = event->pos();
}

void ItemView::lineMouseReleaseEvent(QMouseEvent* event)
{
    m_releasedPos = event->pos();
    if (m_pressedPos == m_releasedPos) {
        m_firstClick = !m_firstClick;
        if (m_firstClick) {
            m_point1 = mapToScene(event->pos());
        }
        else {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            m_point2 = mapToScene(event->pos());
            m_line = add_Line();
            m_line->setFlag(QGraphicsItem::ItemIsMovable);
        }
        m_readyToDraw = !m_readyToDraw;
    }
}

void ItemView::lineMouseMoveEvent(QMouseEvent* event)
{
    if (m_readyToDraw) {
        if (m_currentItem) {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
        }
        m_point2 = mapToScene(event->pos());
        m_currentItem = add_Line();
    }
}

QGraphicsLineItem* ItemView::add_Line()
{
    QGraphicsLineItem* l;
    switch(m_layerType) {
        case Layer::LayerType::M1 :
            l = scene->addLine(QLineF(m_point1, m_point2), QPen(Qt::blue, 2));
            break;
        case Layer::LayerType::M2 :
            l = scene->addLine(QLineF(m_point1, m_point2), QPen(Qt::green, 2));
            break;
        case Layer::LayerType::M3 :
            l = scene->addLine(QLineF(m_point1, m_point2), QPen(Qt::red, 2));
            break;
        case Layer::LayerType::M4 :
            l = scene->addLine(QLineF(m_point1, m_point2), QPen(Qt::cyan, 2));
            break;
        case Layer::LayerType::M5 :
            l = scene->addLine(QLineF(m_point1, m_point2), QPen(Qt::magenta, 2));
            break;
    }
    return l;
}

//------------------Functions to draw an CIRCLE------------------

void ItemView::circleMousePressEvent(QMouseEvent* event)
{
    m_pressedPos = event->pos();
}

void ItemView::circleMouseReleaseEvent(QMouseEvent* event)
{
    m_releasedPos = event->pos();
    if (m_pressedPos == m_releasedPos) {
        m_firstClick = !m_firstClick;
        if (m_firstClick) {
            m_point1 = mapToScene(event->pos());
        }
        else {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            m_point2 = mapToScene(event->pos());
            m_circle = add_Circle();
            m_circle->setFlag(QGraphicsItem::ItemIsMovable);
        }
        m_readyToDraw = !m_readyToDraw;
    }
}

void ItemView::circleMouseMoveEvent(QMouseEvent* event)
{
    if (m_readyToDraw) {
        if (m_currentItem) {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
        }
        m_point2 = mapToScene(event->pos());
        m_currentItem = add_Circle();
    }
}

QGraphicsEllipseItem* ItemView::add_Circle()
{
    QGraphicsEllipseItem* ellipse = new QGraphicsEllipseItem;
    int size = qFabs(m_point2.x()) - qFabs(m_point1.x());
    switch(m_layerType) {
        case Layer::LayerType::M1 :
            ellipse = scene->addEllipse(QRectF(QPointF(m_point1), QSizeF(size, size)),
                                        QPen(Qt::blue, 2),
                                        QBrush(Qt::blue, Qt::BDiagPattern));
            break;
        case Layer::LayerType::M2 :
            ellipse = scene->addEllipse(QRectF(QPointF(m_point1), QSizeF(size, size)),
                                        QPen(Qt::green, 2),
                                        QBrush(Qt::green, Qt::Dense7Pattern));
            break;
        case Layer::LayerType::M3 :
            ellipse = scene->addEllipse(QRectF(QPointF(m_point1), QSizeF(size, size)),
                                        QPen(Qt::red, 2),
                                        QBrush(Qt::red, Qt::FDiagPattern));
            break;
        case Layer::LayerType::M4 :
            ellipse = scene->addEllipse(QRectF(QPointF(m_point1), QSizeF(size, size)),
                                        QPen(Qt::cyan, 2),
                                        QBrush(Qt::cyan, Qt::DiagCrossPattern));
            break;
        case Layer::LayerType::M5 :
            ellipse = scene->addEllipse(QRectF(QPointF(m_point1), QSizeF(size, size)),
                                        QPen(Qt::magenta, 2),
                                        QBrush(Qt::magenta, Qt::Dense5Pattern));
            break;
    }
    return ellipse;
}

//------------------Functions to draw a POLYGON------------------

void ItemView::polygonMousePressEvent(QMouseEvent* event)
{
    m_pressedPos = event->pos();
    m_pressCount++;
}

void ItemView::polygonMouseReleaseEvent(QMouseEvent* event)
{
    m_releasedPos = event->pos();
    m_releaseCount++;
    if (m_pressCount == m_releaseCount && m_releasedPos == m_pressedPos) {
        m_clicks++;
        if (m_clicks == 1) {
            m_point1 = mapToScene(event->pos());
            m_polygon.push_back(m_point1);
            m_readyToDraw = true;
        }
        else {
            if (m_currentItem) {
                scene->removeItem(m_currentItem);
                delete m_currentItem;
                m_currentItem = nullptr;
            }
            m_point2 = mapToScene(event->pos());
            m_polygon.push_back(m_point2);
            m_currentItem = add_Polygon();
        }
    }
    else {
        m_pressCount = 0;
        m_releaseCount = 0;
        m_clicks = 0;
    }
}

void ItemView::polygonMouseMoveEvent(QMouseEvent* event)
{
    if (m_readyToDraw) {
        if (m_currentItem) {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            m_polygon.pop_back();
        }
        m_point2 = mapToScene(event->pos());
        m_polygon.push_back(m_point2);
        m_currentItem = add_Polygon();
    }
}

void ItemView::polygonMouseDoubleClickEvent()
{
    if (m_currentItem) {
        m_currentItem->setFlag(QGraphicsItem::ItemIsMovable);
        m_currentItem = nullptr;
    }
    m_readyToDraw = false;
    m_polygon.clear();
}

QGraphicsPolygonItem* ItemView::add_Polygon()
{
    QGraphicsPolygonItem* polygon;
    switch(m_layerType) {
        case Layer::LayerType::M1 :
            polygon = scene->addPolygon(QPolygonF(m_polygon),
                                        QPen(QColor(Qt::blue), 2),
                                        QBrush(QColor(Qt::blue), Qt::BDiagPattern));
            break;
        case Layer::LayerType::M2 :
            polygon = scene->addPolygon(QPolygonF(m_polygon),
                                        QPen(QColor(Qt::green), 2),
                                        QBrush(QColor(Qt::green), Qt::Dense7Pattern));
            break;
        case Layer::LayerType::M3 :
            polygon = scene->addPolygon(QPolygonF(m_polygon),
                                        QPen(QColor(Qt::red), 2),
                                        QBrush(QColor(Qt::red), Qt::FDiagPattern));
            break;
        case Layer::LayerType::M4 :
            polygon = scene->addPolygon(QPolygonF(m_polygon),
                                        QPen(QColor(Qt::cyan), 2),
                                        QBrush(QColor(Qt::cyan), Qt::DiagCrossPattern));
            break;
        case Layer::LayerType::M5 :
            polygon = scene->addPolygon(QPolygonF(m_polygon),
                                        QPen(QColor(Qt::magenta), 2),
                                        QBrush(QColor(Qt::magenta), Qt::Dense5Pattern));
            break;
    }
    return polygon;
}

//------------------Functions to draw a PATH------------------
/*
void ItemView::pathMousePressEvent(QMouseEvent* event)
{
    m_pressedPos = event->pos();
}

void ItemView::pathMouseReleaseEvent(QMouseEvent* event)
{
    m_releasedPos = event->pos();
    if (m_pressedPos == m_releasedPos) {
        m_clicks++; // 1
        if (m_clicks == 1) {
            m_point1 = mapToScene(event->pos());
            m_readyToDraw = true;
        }
        else {
            m_readyToDraw = false;

//            m_path.pop_back();
//            m_path.pop_back();
//            scene->removeItem(m_currentItem);
//            delete m_currentItem;
//            m_currentItem = nullptr;
//            m_point1 = mapToScene(temp);
//            m_path.push_back(QPointF(m_point1.x() - 20, m_point2.y()));
//            m_path.push_back(QPointF(m_point1.x() - 20, m_point1.y()));
//            m_path.push_back(QPointF(m_point1.x() + 20, m_point1.y()));
//            m_path.push_back(QPointF(m_point1.x() + 20, m_point2.y()));
//            m_pathLine = scene->addLine(line, QPen(QColor(Qt::blue), 2));
//            m_currentItem = scene->addPolygon(QPolygonF(m_path),
//                                              QPen(QColor(Qt::blue), 2),
//                                              QBrush(QColor(Qt::blue), Qt::BDiagPattern));
//            m_readyToDraw = false;

//            scene->removeItem(m_currentItem);
//            delete m_currentItem;
//            m_currentItem = nullptr;
//            m_path.clear();
//            scene->removeItem(m_pathLine);
//            delete m_pathLine;
//            m_pathLine = nullptr;
//            m_point2 = mapToScene(event->pos());
//            m_currentItem = add_Path();
//            m_point1 = mapToScene(event->pos());
        }
    }
}

void ItemView::pathMouseMoveEvent(QMouseEvent* event)
{
    if (m_readyToDraw) {
        if (m_currentItem) {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            for (int i = 0; i < 4; ++i) {
                m_path.pop_back();
            }
            scene->removeItem(m_pathLine);
            delete m_pathLine;
            m_pathLine = nullptr;
        }
        m_point2 = mapToScene(event->pos());
        m_currentItem = add_Path();
    }
}

void ItemView::pathMouseDoubleClickEvent(QMouseEvent* )
{

}

QGraphicsPolygonItem* ItemView::add_Path()
{
    QGraphicsPolygonItem* path;
    createVector();
    switch(m_layerType) {
        case Layer::LayerType::M1 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::blue), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::blue), 2),
                                     QBrush(QColor(Qt::blue), Qt::BDiagPattern));
            break;
        case Layer::LayerType::M2 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::green), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::green), 2),
                                     QBrush(QColor(Qt::green), Qt::Dense7Pattern));
            break;
        case Layer::LayerType::M3 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::red), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::red), 2),
                                     QBrush(QColor(Qt::red), Qt::FDiagPattern));
            break;
        case Layer::LayerType::M4 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::cyan), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::cyan), 2),
                                     QBrush(QColor(Qt::cyan), Qt::DiagCrossPattern));
            break;
        case Layer::LayerType::M5 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::magenta), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::magenta), 2),
                                     QBrush(QColor(Qt::magenta), Qt::Dense5Pattern));
            break;
    }
    return path;
}

void ItemView::pathDrawingDirection()
{

}

void ItemView::createVector()
{
    int a{20};
    if (m_readyToDraw) {
        if (m_point2.x() > m_point1.x() &&
            fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m_path.push_back(QPointF(m_point1.x(), m_point1.y() + a));
            m_path.push_back(QPointF(m_point1.x(), m_point1.y() - a));
            m_path.push_back(QPointF(m_point2.x(), m_point1.y() - a));
            m_path.push_back(QPointF(m_point2.x(), m_point1.y() + a));
//            temp = QPoint(m_point2.x() - a, m_point1.y());
            temp = QPoint(m_point2.x(), m_point1.y());
            line = QLineF(m_point1, QPointF(m_point2.x(), m_point1.y()));
        }
        else if (m_point2.x() < m_point1.x() &&
                 fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m_path.push_back(QPointF(m_point1.x(), m_point1.y() + a));
            m_path.push_back(QPointF(m_point1.x(), m_point1.y() - a));
            m_path.push_back(QPointF(m_point2.x(), m_point1.y() - a));
            m_path.push_back(QPointF(m_point2.x(), m_point1.y() + a));
//            temp = QPoint(m_point2.x() + a, m_point1.y());
            temp = QPoint(m_point2.x(), m_point1.y());
            line = QLineF(m_point1, QPointF(m_point2.x(), m_point1.y()));
        }
        else if (m_point2.y() < m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m_path.push_back(QPointF(m_point1.x() + a, m_point1.y()));
            m_path.push_back(QPointF(m_point1.x() - a, m_point1.y()));
            m_path.push_back(QPointF(m_point1.x() - a, m_point2.y()));
            m_path.push_back(QPointF(m_point1.x() + a, m_point2.y()));
//            temp = QPoint(m_point1.x(), m_point2.y() + a);
            temp = QPoint(m_point1.x(), m_point2.y());
            line = QLineF(m_point1, QPointF(m_point1.x(), m_point2.y()));
        }
        else if (m_point2.y() > m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m_path.push_back(QPointF(m_point1.x() + a, m_point1.y()));
            m_path.push_back(QPointF(m_point1.x() - a, m_point1.y()));
            m_path.push_back(QPointF(m_point1.x() - a, m_point2.y()));
            m_path.push_back(QPointF(m_point1.x() + a, m_point2.y()));
//            temp = QPoint(m_point1.x(), m_point2.y() - a);
            temp = QPoint(m_point1.x(), m_point2.y());
            line = QLineF(m_point1, QPointF(m_point1.x(), m_point2.y()));
        }
    }
}
*/
/*
void ItemView::pathMousePressEvent(QMouseEvent* event)
{
    m_pressedPos = event->pos();
}

void ItemView::pathMouseReleaseEvent(QMouseEvent* event)
{
    m_releasedPos = event->pos();
    if (m_pressedPos == m_releasedPos) {
        m_clicks++; // 1
        if (m_clicks == 1) {
            m_point1 = mapToScene(event->pos());
            m_readyToDraw = true;
        }
        else {
            scene->removeItem(m_currentItem);
            delete  m_currentItem;
            m_currentItem = nullptr;
            for (int i = 0; i < 4; ++i) {
                m_path.pop_back();
            }
            scene->removeItem(m_pathLine);
            delete m_pathLine;
            m_pathLine = nullptr;
            m_point2 = mapToScene(event->pos());
            m_currentItem = add_Path();
        }
    }
}

void ItemView::pathMouseMoveEvent(QMouseEvent* event)
{
    if (m_readyToDraw) {
        if (m_currentItem) {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            for (int i = 0; i < 4; ++i) {
                m_path.pop_back();
            }
            scene->removeItem(m_pathLine);
            delete m_pathLine;
            m_pathLine = nullptr;
        }
        m_point2 = mapToScene(event->pos());
        m_currentItem = add_Path();
    }
}

void ItemView::pathMouseDoubleClickEvent(QMouseEvent* )
{

}

QGraphicsPolygonItem* ItemView::add_Path()
{
    QGraphicsPolygonItem* path;
    createVector();
    switch(m_layerType) {
        case Layer::LayerType::M1 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::blue), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::blue), 2),
                                     QBrush(QColor(Qt::blue), Qt::BDiagPattern));
            break;
        case Layer::LayerType::M2 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::green), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::green), 2),
                                     QBrush(QColor(Qt::green), Qt::Dense7Pattern));
            break;
        case Layer::LayerType::M3 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::red), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::red), 2),
                                     QBrush(QColor(Qt::red), Qt::FDiagPattern));
            break;
        case Layer::LayerType::M4 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::cyan), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::cyan), 2),
                                     QBrush(QColor(Qt::cyan), Qt::DiagCrossPattern));
            break;
        case Layer::LayerType::M5 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::magenta), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::magenta), 2),
                                     QBrush(QColor(Qt::magenta), Qt::Dense5Pattern));
            break;
    }
    return path;
}

void ItemView::pathDrawingDirection()
{
    int a{20};
    if (m_clicks == 1) {
        if (m_point2.x() > m_point1.x() &&
            fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m = 1;
            point1 = QPointF(m_point1.x(), m_point1.y() + a);
            point2 = QPointF(m_point1.x(), m_point1.y() - a);
            point3 = QPointF(m_point2.x(), m_point1.y() - a);
            point4 = QPointF(m_point2.x(), m_point1.y() + a);
        }

        else if (m_point2.x() < m_point1.x() &&
                 fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m = 2;
            point1 = QPointF(m_point1.x(), m_point1.y() + a);
            point2 = QPointF(m_point1.x(), m_point1.y() - a);
            point3 = QPointF(m_point2.x(), m_point1.y() - a);
            point4 = QPointF(m_point2.x(), m_point1.y() + a);
        }

        else if (m_point2.y() < m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m = 3;
            point1 = QPointF(m_point1.x() + a, m_point1.y());
            point2 = QPointF(m_point1.x() - a, m_point1.y());
            point3 = QPointF(m_point1.x() - a, m_point2.y());
            point4 = QPointF(m_point1.x() + a, m_point2.y());
        }

        else if (m_point2.y() > m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m = 4;
            point1 = QPointF(m_point1.x() + a, m_point1.y());
            point2 = QPointF(m_point1.x() - a, m_point1.y());
            point3 = QPointF(m_point1.x() - a, m_point2.y());
            point4 = QPointF(m_point1.x() + a, m_point2.y());
        }
    }
    else {
        if (m == 1) {
            if (m_point2.y() < m_point1.y()) {
                point1 = QPointF(temp.x() - a, temp.y() - a);
                point2 = QPointF(m_point2.x() - a, m_point2.y());
                point3 = QPointF(m_point2.x() + a, m_point2.y());
                point4 = QPointF(temp.x() + a, temp.y() + a);
            }
            else if (m_point2.y() > m_point1.y()) {
                point1 = QPointF(temp.x() + a, temp.y() - a);
                point2 = QPointF(m_point2.x() + a, m_point2.y());
                point3 = QPointF(); /////////////
            }
        }

        if (m == 2) {
            if (m_point2.y() < m_point1.y()) {

            }
            else if (m_point2.y() > m_point1.y()) {

            }
        }

        if (m == 3) {
            if (m_point2.x() > m_point1.x()) {

            }
            else if (m_point2.x() < m_point1.x()) {

            }
        }

        if (m == 4) {
            if (m_point2.x() > m_point1.x()) {

            }
            else if (m_point2.x() < m_point1.x()) {

            }
        }
    }
}

void ItemView::createVector()
{
    pathDrawingDirection();
    if (m_point2.x() > m_point1.x() &&
        fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
    {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
        temp = QPoint(m_point2.x(), m_point1.y());
        line = QLineF(m_point1, temp);
    }

    else if (m_point2.x() < m_point1.x() &&
             fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
    {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
        temp = QPoint(m_point2.x(), m_point1.y());
        line = QLineF(m_point1, temp);
    }

    else if (m_point2.y() < m_point1.y() &&
             fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
    {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
        temp = QPoint(m_point1.x(), m_point2.y());
        line = QLineF(m_point1, temp);
    }

    else if (m_point2.y() > m_point1.y() &&
             fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
    {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
        temp = QPoint(m_point1.x(), m_point2.y());
        line = QLineF(m_point1, temp);
    }
}
*/
/*
void ItemView::pathMousePressEvent(QMouseEvent* event)
{
    m_pressedPos = event->pos();
}

void ItemView::pathMouseReleaseEvent(QMouseEvent* event)
{
    m_releasedPos = event->pos();
    if (m_pressedPos == m_releasedPos) {
        m_clicks++; // 1
        if (m_clicks == 1) {
            m_point1 = mapToScene(event->pos());
            m_readyToDraw = true;
        }
        else {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            for (int i = 0; i < 2; ++i) {
                m_path.pop_back();
            }
            scene->removeItem(m_pathLine);
            delete m_pathLine;
            m_pathLine = nullptr;
            m_point2 = mapToScene(event->pos());
            m_currentItem = add_Path();
        }
    }
}

void ItemView::pathMouseMoveEvent(QMouseEvent* event)
{
    if (m_readyToDraw) {
        if (m_currentItem) {
            int a;
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            if (m_clicks == 1) {
                a = 4;
            }
            else {
                a = 2;
            }
            for (int i = 0; i < a; ++i) {
                m_path.pop_back();
            }
            scene->removeItem(m_pathLine);
            delete m_pathLine;
            m_pathLine = nullptr;
        }
        m_point2 = mapToScene(event->pos());
        m_currentItem = add_Path();
    }
}

void ItemView::pathMouseDoubleClickEvent(QMouseEvent* )
{

}

QGraphicsPolygonItem* ItemView::add_Path()
{
    QGraphicsPolygonItem* path;
    createVector();
//    if (m_clicks > 1) { // { a, b, c, d, e, f }
//        QPointF t = m_path.first();
//        m_path.first() = m_path.last();
//        m_path.last() = t;
//    }
    switch(m_layerType) {
        case Layer::LayerType::M1 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::blue), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::blue), 2),
                                     QBrush(QColor(Qt::blue), Qt::BDiagPattern));
            break;
        case Layer::LayerType::M2 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::green), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::green), 2),
                                     QBrush(QColor(Qt::green), Qt::Dense7Pattern));
            break;
        case Layer::LayerType::M3 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::red), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::red), 2),
                                     QBrush(QColor(Qt::red), Qt::FDiagPattern));
            break;
        case Layer::LayerType::M4 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::cyan), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::cyan), 2),
                                     QBrush(QColor(Qt::cyan), Qt::DiagCrossPattern));
            break;
        case Layer::LayerType::M5 :
            m_pathLine = scene->addLine(line, QPen(QColor(Qt::magenta), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::magenta), 2),
                                     QBrush(QColor(Qt::magenta), Qt::Dense5Pattern));
            break;
    }
    return path;
}

void ItemView::createVector()
{
    pathDrawingDirection();     // m_path { a, b, c, d }, { a, b }, { a, b, c, d, e, f }
    if (m == 1)
    {
        m_path.push_back(point1);   // { a }            { a, b, c }
        m_path.push_back(point2);   // { a, b }         { a, b, c, d }
        m_path.push_back(point3);   // { a, b, c }      { a, b, c, d, e }
        m_path.push_back(point4);   // { a, b, c, d }   { a, b, c, d, e, f }
//        temp = QPoint(m_point2.x(), m_point1.y());
//        line = QLineF(m_point1, temp);
        m_tempPoint = QPointF(m_point2.x(), m_point1.y());
        line = QLineF(m_point1, m_tempPoint);
    }
    else if (m_point2.x() < m_point1.x() &&
             fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
    {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
        temp = QPoint(m_point2.x(), m_point1.y());
        line = QLineF(m_point1, temp);
    }
    else if (m_point2.y() < m_point1.y() &&
             fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
    {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
        temp = QPoint(m_point1.x(), m_point2.y());
        line = QLineF(m_point1, temp);
    }
    else if (m_point2.y() > m_point1.y() &&
             fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
    {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
        temp = QPoint(m_point1.x(), m_point2.y());
        line = QLineF(m_point1, temp);
    }
}

void ItemView::pathDrawingDirection()
{
    int a{20};
    if (m_clicks == 1) {
        if (m_point2.x() > m_point1.x() &&
            fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m = 1;
            point1 = QPointF(m_point1.x(), m_point1.y() + a);   // a
            point2 = QPointF(m_point1.x(), m_point1.y() - a);   // b
            point3 = QPointF(m_point2.x(), m_point1.y() - a);   // c
            point4 = QPointF(m_point2.x(), m_point1.y() + a);   // d
        }
        else if (m_point2.x() < m_point1.x() &&
                 fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m = 2;
            point1 = QPointF(m_point1.x(), m_point1.y() + a);
            point2 = QPointF(m_point1.x(), m_point1.y() - a);
            point3 = QPointF(m_point2.x(), m_point1.y() - a);
            point4 = QPointF(m_point2.x(), m_point1.y() + a);
        }
        else if (m_point2.y() < m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m = 3;
            point1 = QPointF(m_point1.x() + a, m_point1.y());
            point2 = QPointF(m_point1.x() - a, m_point1.y());
            point3 = QPointF(m_point1.x() - a, m_point2.y());
            point4 = QPointF(m_point1.x() + a, m_point2.y());
        }
        else if (m_point2.y() > m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m = 4;
            point1 = QPointF(m_point1.x() + a, m_point1.y());
            point2 = QPointF(m_point1.x() - a, m_point1.y());
            point3 = QPointF(m_point1.x() - a, m_point2.y());
            point4 = QPointF(m_point1.x() + a, m_point2.y());
        }
    }
    else {
        if (m == 1) {
            if (m_point2.y() < m_point1.y()) {
                point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a); // c
                point2 = QPointF(m_point2.x() - a, m_point2.y());           // d
                point3 = QPointF(m_point2.x() + a, m_point2.y());           // e
                point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() + a); // f
            }
            else if (m_point2.y() > m_point1.y()) {
                point1 = QPointF(temp.x() + a, temp.y() - a);
                point2 = QPointF(m_point2.x() + a, m_point2.y());
                point3 = QPointF(); /////////////
            }
        }
        if (m == 2) {
            if (m_point2.y() < m_point1.y()) {

            }
            else if (m_point2.y() > m_point1.y()) {

            }
        }
        if (m == 3) {
            if (m_point2.x() > m_point1.x()) {

            }
            else if (m_point2.x() < m_point1.x()) {

            }
        }
        if (m == 4) {
            if (m_point2.x() > m_point1.x()) {

            }
            else if (m_point2.x() < m_point1.x()) {

            }
        }
    }
}
*/

// best one
/*
void ItemView::pathMousePressEvent(QMouseEvent* event)
{
    m_pressedPos = event->pos();
}

void ItemView::pathMouseReleaseEvent(QMouseEvent* event)
{
    m_releasedPos = event->pos();
    if (m_pressedPos == m_releasedPos) {
        m_clicks++;
        if (m_clicks == 1) {
            m_point1 = mapToScene(event->pos());
            m_readyToDraw = true;
        }
        else {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            for (int i = 0; i < 2; ++i) {
                m_path.pop_back();
            }
            m_point2 = mapToScene(event->pos());
            m_currentItem = add_Path();
            m_readyToDraw = false;
        }
    }
}

void ItemView::pathMouseMoveEvent(QMouseEvent* event)
{
    if (m_readyToDraw) {
        if (m_currentItem) {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            if (m_clicks == 1) {
                for (int i = 0; i < 4; ++i) {
                    m_path.pop_back();
                }
            }
            else {
                for (int i = 0; i < 2; ++i) {
                    m_path.pop_back();
                }
            }
            scene->removeItem(m_pathLine);
            delete m_pathLine;
            m_pathLine = nullptr;
        }
        m_point2 = mapToScene(event->pos());
        m_currentItem = add_Path();
    }
}

void ItemView::pathMouseDoubleClickEvent(QMouseEvent* )
{

}

QGraphicsPolygonItem* ItemView::add_Path()
{
    createVector();
    if (m_clicks > 1) {
        QPointF t = m_path.last();
        m_path.pop_back();
        m_path.insert(m_path.begin(), t);
    }
    QGraphicsPolygonItem* path;
    switch(m_layerType) {
        case Layer::LayerType::M1 :
            m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::blue), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::blue), 2),
                                     QBrush(QColor(Qt::blue), Qt::BDiagPattern));
            break;
        case Layer::LayerType::M2 :
            m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::green), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::green), 2),
                                     QBrush(QColor(Qt::green), Qt::Dense7Pattern));
            break;
        case Layer::LayerType::M3 :
            m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::red), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::red), 2),
                                     QBrush(QColor(Qt::red), Qt::FDiagPattern));
            break;
        case Layer::LayerType::M4 :
            m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::cyan), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::cyan), 2),
                                     QBrush(QColor(Qt::cyan), Qt::DiagCrossPattern));
            break;
        case Layer::LayerType::M5 :
            m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::magenta), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::magenta), 2),
                                     QBrush(QColor(Qt::magenta), Qt::Dense5Pattern));
            break;
    }
    return path;
}

void ItemView::createVector()
{
    pathDrawingDirection();
    if (m == 1) {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
    }
    else if (m == 2) {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
    }
    else if (m == 3) {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
    }
    else if (m == 4) {
        m_path.push_back(point1);
        m_path.push_back(point2);
        m_path.push_back(point3);
        m_path.push_back(point4);
    }
}

void ItemView::pathDrawingDirection()
{
    int a{20};
    if (m_clicks == 1) {
        if (m_point2.x() > m_point1.x() &&
            fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m = 1;
            point1 = QPointF(m_point1.x(), m_point1.y() + a);
            point2 = QPointF(m_point1.x(), m_point1.y() - a);
            point3 = QPointF(m_point2.x(), m_point1.y() - a);
            point4 = QPointF(m_point2.x(), m_point1.y() + a);
            m_tempPoint = QPointF(m_point2.x(), m_point1.y());
        }
        else if (m_point2.x() < m_point1.x() &&
                 fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m = 2;
            point1 = QPointF(m_point1.x(), m_point1.y() + a);
            point2 = QPointF(m_point1.x(), m_point1.y() - a);
            point3 = QPointF(m_point2.x(), m_point1.y() - a);
            point4 = QPointF(m_point2.x(), m_point1.y() + a);
            m_tempPoint = QPointF(m_point2.x(), m_point1.y());
        }
        else if (m_point2.y() < m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m = 3;
            point1 = QPointF(m_point1.x() + a, m_point1.y());
            point2 = QPointF(m_point1.x() - a, m_point1.y());
            point3 = QPointF(m_point1.x() - a, m_point2.y());
            point4 = QPointF(m_point1.x() + a, m_point2.y());
            m_tempPoint = QPointF(m_point1.x(), m_point2.y());
        }
        else if (m_point2.y() > m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m = 4;
            point1 = QPointF(m_point1.x() + a, m_point1.y());
            point2 = QPointF(m_point1.x() - a, m_point1.y());
            point3 = QPointF(m_point1.x() - a, m_point2.y());
            point4 = QPointF(m_point1.x() + a, m_point2.y());
            m_tempPoint = QPointF(m_point1.x(), m_point2.y());
        }
    }
    else {
        if (m == 1) {
            if (m_point2.y() < m_tempPoint.y()) {
                point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a);
                point2 = QPointF(m_point2.x() - a, m_point2.y());
                point3 = QPointF(m_point2.x() + a, m_point2.y());
                point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() + a);
                m_point1 = m_tempPoint;
                m_tempPoint = m_point2;
            }
            else if (m_point2.y() > m_tempPoint.y()) {
                point1 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() - a);
                point2 = QPointF(m_point2.x() + a, m_point2.y());
                point3 = QPointF(m_point2.x() - a, m_point2.y());
                point4 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() + a);
                m_point1 = m_tempPoint;
                m_tempPoint = m_point2;
            }
        }
        if (m == 2) {
            if (m_point2.y() < m_point1.y()) {
                point1 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() - a);
                point2 = QPointF(m_point2.x() + a, m_point2.y());
                point3 = QPointF(m_point2.x() - a, m_point2.y());
                point4 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() + a);
                m_point1 = m_tempPoint;
                m_tempPoint = m_point2;
            }
            else if (m_point2.y() > m_point1.y()) {
                point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a);
                point2 = QPointF(m_point2.x() - a, m_point2.y());
                point3 = QPointF(m_point2.x() + a, m_point2.y());
                point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() + a);
                m_point1 = m_tempPoint;
                m_tempPoint = m_point2;
            }
        }
        if (m == 3) {
            if (m_point2.x() > m_point1.x()) {
                point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a);
                point2 = QPointF(m_point2.x(), m_point2.y() - a);
                point3 = QPointF(m_point2.x(), m_point2.y() + a);
                point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() + a);
                m_point1 = m_tempPoint;
                m_tempPoint = m_point2;
            }
            else if (m_point2.x() < m_point1.x()) {
                point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() + a);
                point2 = QPointF(m_point2.x(), m_point2.y() + a);
                point3 = QPointF(m_point2.x(), m_point2.y() - a);
                point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() - a);
                m_point1 = m_tempPoint;
                m_tempPoint = m_point2;
            }
        }
        if (m == 4) {
            if (m_point2.x() > m_point1.x()) {
                point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() + a);
                point2 = QPointF(m_point2.x(), m_point2.y() + a);
                point3 = QPointF(m_point2.x(), m_point2.y() - a);
                point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() - a);
                m_point1 = m_tempPoint;
                m_tempPoint = m_point2;
            }
            else if (m_point2.x() < m_point1.x()) {
                point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a);
                point2 = QPointF(m_point2.x(), m_point2.y() - a);
                point3 = QPointF(m_point2.x(), m_point2.y() + a);
                point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() + a);
                m_point1 = m_tempPoint;
                m_tempPoint = m_point2;
            }
        }
    }
}
*/

void ItemView::pathMousePressEvent(QMouseEvent* event)
{
    m_pressedPos = event->pos();
}

void ItemView::pathMouseReleaseEvent(QMouseEvent* event)
{
    m_releasedPos = event->pos();
    if (m_pressedPos == m_releasedPos) {
        m_clicks++;
        if (m_clicks == 1) {
            m_point1 = mapToScene(event->pos());
            m_readyToDraw = true;
        }
        else {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            for (int i = 0; i < 2; ++i) {
                m_path.pop_back();
            }
            m_point2 = mapToScene(event->pos());
            m_mouseIsClicked = true;
            m_currentItem = add_Path();
            m_point1 = m_point2;
        }
    }
}

void ItemView::pathMouseMoveEvent(QMouseEvent* event)
{
    if (m_readyToDraw) {
        if (m_currentItem) {
            scene->removeItem(m_currentItem);
            delete m_currentItem;
            m_currentItem = nullptr;
            if (m_clicks == 1) {
                for (int i = 0; i < 4; ++i) {
                    m_path.pop_back();
                }
            }
            else {
                for (int i = 0; i < 2; ++i) {
                    m_path.pop_back();
                }
            }
            scene->removeItem(m_pathLine);
            delete m_pathLine;
            m_pathLine = nullptr;
        }
        m_point2 = mapToScene(event->pos());
        m_mouseIsClicked = false;
        m_currentItem = add_Path();
    }
}

void ItemView::pathMouseDoubleClickEvent(QMouseEvent* )
{

}

QGraphicsPolygonItem* ItemView::add_Path()
{
    createVector();
    QGraphicsPolygonItem* path;
    switch(m_layerType) {
        case Layer::LayerType::M1 :
            if (m_mouseIsClicked) {
                m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::blue), 2));
                m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::blue), 2));
            }
            else {
                m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::blue), 2));
            }
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::blue), 2),
                                     QBrush(QColor(Qt::blue), Qt::BDiagPattern));
            break;
        case Layer::LayerType::M2 :
            m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::green), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::green), 2),
                                     QBrush(QColor(Qt::green), Qt::Dense7Pattern));
            break;
        case Layer::LayerType::M3 :
            m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::red), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::red), 2),
                                     QBrush(QColor(Qt::red), Qt::FDiagPattern));
            break;
        case Layer::LayerType::M4 :
            m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::cyan), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::cyan), 2),
                                     QBrush(QColor(Qt::cyan), Qt::DiagCrossPattern));
            break;
        case Layer::LayerType::M5 :
            m_pathLine = scene->addLine(QLineF(m_point1, m_tempPoint), QPen(QColor(Qt::magenta), 2));
            path = scene->addPolygon(QPolygonF(m_path),
                                     QPen(QColor(Qt::magenta), 2),
                                     QBrush(QColor(Qt::magenta), Qt::Dense5Pattern));
            break;
    }
    return path;
}

void ItemView::createVector()
{
    pathDrawingDirection();
    m_path.push_back(point1);
    m_path.push_back(point2);
    m_path.push_back(point3);
    m_path.push_back(point4);

    if (m_mouseIsClicked) {
        if (m_clicks == 2) {
            QPointF t = m_path.last();
            m_path.pop_back();
            m_path.insert(m_path.begin(), t);
        }
        else if (m_clicks > 2) {
            QPointF t = m_path.last();
            m_path.pop_back();
            m_path.insert(m_path.begin(), t);
            t = m_path.last();
            m_path.pop_back();
            m_path.insert(m_path.begin() + 1, t);
        }
    }
}

void ItemView::pathDrawingDirection()
{
    int a{20};
    if (m_clicks == 1) {
        if (m_point2.x() > m_point1.x() &&
            fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m = 1;
            point1 = QPointF(m_point1.x(), m_point1.y() + a);
            point2 = QPointF(m_point1.x(), m_point1.y() - a);
            point3 = QPointF(m_point2.x(), m_point1.y() - a);
            point4 = QPointF(m_point2.x(), m_point1.y() + a);
            m_tempPoint = QPointF(m_point2.x(), m_point1.y());
        }
        else if (m_point2.x() < m_point1.x() &&
                 fabs(m_point2.y() - m_point1.y()) <= fabs(m_point2.x() - m_point1.x()))
        {
            m = 2;
            point1 = QPointF(m_point1.x(), m_point1.y() - a);
            point2 = QPointF(m_point1.x(), m_point1.y() + a);
            point3 = QPointF(m_point2.x(), m_point1.y() + a);
            point4 = QPointF(m_point2.x(), m_point1.y() - a);
            m_tempPoint = QPointF(m_point2.x(), m_point1.y());
        }
        else if (m_point2.y() < m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m = 3;
            point1 = QPointF(m_point1.x() + a, m_point1.y());
            point2 = QPointF(m_point1.x() - a, m_point1.y());
            point3 = QPointF(m_point1.x() - a, m_point2.y());
            point4 = QPointF(m_point1.x() + a, m_point2.y());
            m_tempPoint = QPointF(m_point1.x(), m_point2.y());
        }
        else if (m_point2.y() > m_point1.y() &&
                 fabs(m_point2.x() - m_point1.x()) <= fabs(m_point2.y() - m_point1.y()))
        {
            m = 4;
            point1 = QPointF(m_point1.x() - a, m_point1.y());
            point2 = QPointF(m_point1.x() + a, m_point1.y());
            point3 = QPointF(m_point1.x() + a, m_point2.y());
            point4 = QPointF(m_point1.x() - a, m_point2.y());
            m_tempPoint = QPointF(m_point1.x(), m_point2.y());
        }
    }
    else {
        if (m_mouseIsClicked) {
            std::cout << "m = " << m << std::endl;
            if (m == 1) {
                if (m_point2.y() < m_tempPoint.y()) {
                    m = 3;
                    point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a);
                    point2 = QPointF(m_point2.x() - a, m_point2.y());
                    point3 = QPointF(m_point2.x() + a, m_point2.y());
                    point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() + a);
                    m_point1 = m_tempPoint;
                    m_tempPoint = m_point2;
                }
                else if (m_point2.y() > m_tempPoint.y()) {
                    m = 4;
                    point1 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() - a);
                    point2 = QPointF(m_point2.x() + a, m_point2.y());
                    point3 = QPointF(m_point2.x() - a, m_point2.y());
                    point4 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() + a);
                    m_point1 = m_tempPoint;
                    m_tempPoint = m_point2;
                }
            }
            else if (m == 2) {
                if (m_point2.y() < m_point1.y()) {
                    m = 3;
                    point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() + a);
                    point2 = QPointF(m_point2.x() - a, m_point2.y());
                    point3 = QPointF(m_point2.x() + a, m_point2.y());
                    point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() - a);
                    m_point1 = m_tempPoint;
                    m_tempPoint = m_point2;
                }
                else if (m_point2.y() > m_point1.y()) {
                    m = 4;
                    point1 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() + a);
                    point2 = QPointF(m_point2.x() + a, m_point2.y());
                    point3 = QPointF(m_point2.x() - a, m_point2.y());
                    point4 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a);
                    m_point1 = m_tempPoint;
                    m_tempPoint = m_point2;
                }
            }
            else if (m == 3) {
                if (m_point2.x() > m_point1.x()) {
                    m = 1;
                    point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a);
                    point2 = QPointF(m_point2.x(), m_point2.y() - a);
                    point3 = QPointF(m_point2.x(), m_point2.y() + a);
                    point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() + a);
                    m_point1 = m_tempPoint;
                    m_tempPoint = m_point2;
                }
                else if (m_point2.x() < m_point1.x()) {
                    m = 2;
                    point1 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() + a);
                    point2 = QPointF(m_point2.x(), m_point2.y() + a);
                    point3 = QPointF(m_point2.x(), m_point2.y() - a);
                    point4 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() - a);
                    m_point1 = m_tempPoint;
                    m_tempPoint = m_point2;
                }
            }
            else if (m == 4) {
                if (m_point2.x() > m_point1.x()) {
                    m = 1;
                    point1 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() - a);
                    point2 = QPointF(m_point2.x(), m_point2.y() - a);
                    point3 = QPointF(m_point2.x(), m_point2.y() + a);
                    point4 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() + a);
                    m_point1 = m_tempPoint;
                    m_tempPoint = m_point2;
                }
                else if (m_point2.x() < m_point1.x()) {
                    m = 2;
                    point1 = QPointF(m_tempPoint.x() + a, m_tempPoint.y() + a);
                    point2 = QPointF(m_point2.x(), m_point2.y() + a);
                    point3 = QPointF(m_point2.x(), m_point2.y() - a);
                    point4 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a);
                    m_point1 = m_tempPoint;
                    m_tempPoint = m_point2;
                }
            }
        }
        else {  //////////////////////// mouse is moving
            std::cout << "m = " << m << std::endl;
            if (m == 1) {
                m_tempPoint = QPointF(m_point1.x(), m_point2.y());
                if (m_point2.y() < m_point1.y()) {
                    point1 = QPointF(m_point1.x() - a, m_point1.y() - a);
                    point2 = QPointF(m_tempPoint.x() - a, m_tempPoint.y());
                    point3 = QPointF(m_tempPoint.x() + a, m_tempPoint.y());
                    point4 = QPointF(m_point1.x() + a, m_point1.y() + a);
                }
                else if (m_point2.y() > m_point1.y()) {
                    point1 = QPointF(m_point1.x() + a, m_point1.y() - a);
                    point2 = QPointF(m_tempPoint.x() + a, m_tempPoint.y());
                    point3 = QPointF(m_tempPoint.x() - a, m_tempPoint.y());
                    point4 = QPointF(m_point1.x() - a, m_point1.y() + a);
                }
            }
            else if (m == 2) {
                m_tempPoint = QPointF(m_point1.x(), m_point2.y());
                if (m_point2.y() < m_point1.y()) {
                    point1 = QPointF(m_point1.x() - a, m_point1.y() + a);
                    point2 = QPointF(m_tempPoint.x() - a, m_tempPoint.y());
                    point3 = QPointF(m_tempPoint.x() + a, m_tempPoint.y());
                    point4 = QPointF(m_point1.x() + a, m_point1.y() - a);
                }
                else if (m_point2.y() > m_point1.y()) {
                    point1 = QPointF(m_point1.x() + a, m_point1.y() + a);
                    point2 = QPointF(m_tempPoint.x() + a, m_tempPoint.y());
                    point3 = QPointF(m_tempPoint.x() - a, m_tempPoint.y());
                    point4 = QPointF(m_point1.x() - a, m_point1.y() - a);
                }
            }
            else if (m == 3) {
                m_tempPoint = QPointF(m_point2.x(), m_point1.y());
                if (m_point2.x() > m_point1.x()) {
                    point1 = QPointF(m_point1.x() - a, m_point1.y() - a);
                    point2 = QPointF(m_tempPoint.x(), m_tempPoint.y() - a);
                    point3 = QPointF(m_tempPoint.x(), m_tempPoint.y() + a);
                    point4 = QPointF(m_point1.x() + a, m_point1.y() + a);
                }
                else if (m_point2.x() < m_point1.x()) {
                    point1 = QPointF(m_point1.x() - a, m_point1.y() + a);
                    point2 = QPointF(m_tempPoint.x(), m_tempPoint.y() + a);
                    point3 = QPointF(m_tempPoint.x(), m_tempPoint.y() - a);
                    point4 = QPointF(m_point1.x() + a, m_point1.y() - a);
                }
            }
            else if (m == 4) {
                m_tempPoint = QPointF(m_point2.x(), m_point1.y());
                if (m_point2.x() > m_point1.x()) {
                    point1 = QPointF(m_point1.x() + a, m_point1.y() - a);
                    point2 = QPointF(m_tempPoint.x(), m_tempPoint.y() - a);
                    point3 = QPointF(m_tempPoint.x(), m_tempPoint.y() + a);
                    point4 = QPointF(m_point1.x() - a, m_point1.y() + a);
                }
                else if (m_point2.x() < m_point1.x()) {
                    point1 = QPointF(m_point1.x() + a, m_point1.y() + a);
                    point2 = QPointF(m_tempPoint.x(), m_tempPoint.y() + a);
                    point3 = QPointF(m_tempPoint.x(), m_tempPoint.y() - a);
                    point4 = QPointF(m_tempPoint.x() - a, m_tempPoint.y() - a);
                }
            }
        }
    }
}

