#ifndef ITEMVIEW_H
#define ITEMVIEW_H
#include "Types.h"

#include <QGraphicsView>
#include <QGraphicsItem>
#include <QGraphicsScene>

// ItemView is the canvas
class ItemView : public QGraphicsView
{
public:
    ItemView();

    void createVector();

    QGraphicsRectItem* add_Rectangle();
    QGraphicsLineItem* add_Line();
    QGraphicsEllipseItem* add_Circle();
    QGraphicsPolygonItem* add_Polygon();
    QGraphicsPolygonItem* add_Path();
    void rectDrawingDirection();
    void pathDrawingDirection();
    void createBackground();
    QPoint* mapToBackground(QPoint point);

    // Mouse events for all shapes
    void mousePressEvent(QMouseEvent*) override;
    void mouseReleaseEvent(QMouseEvent*) override;
    void mouseMoveEvent(QMouseEvent*) override;
    void mouseDoubleClickEvent(QMouseEvent*) override;

    // Mouse events for drawing a rectangle
    void rectangleMousePressEvent(QMouseEvent*);
    void rectangleMouseReleaseEvent(QMouseEvent*);
    void rectangleMouseMoveEvent(QMouseEvent*);

    // Mouse events for drawing a line
    void lineMousePressEvent(QMouseEvent*);
    void lineMouseReleaseEvent(QMouseEvent*);
    void lineMouseMoveEvent(QMouseEvent*);

    // Mouse events for drawing an ellipse
    void circleMousePressEvent(QMouseEvent*);
    void circleMouseReleaseEvent(QMouseEvent*);
    void circleMouseMoveEvent(QMouseEvent*);

    // Mouse events for drawing a polygon
    void polygonMousePressEvent(QMouseEvent*);
    void polygonMouseReleaseEvent(QMouseEvent*);
    void polygonMouseMoveEvent(QMouseEvent*);
    void polygonMouseDoubleClickEvent();

    // Mouse events for drawing a path
    void pathMousePressEvent(QMouseEvent*);
    void pathMouseReleaseEvent(QMouseEvent*);
    void pathMouseMoveEvent(QMouseEvent*);
    void pathMouseDoubleClickEvent(QMouseEvent*);

public slots:
    void recieveLayerType(Layer::LayerType);
    void recieveShapeType(Shapes::ShapeType);

private:
    int m_clicks = 0;
    int m_pressCount = 0;
    int m_releaseCount = 0;
    bool m_firstClick;
    bool m_readyToDraw;
    bool m_mouseIsClicked = false;
    QPointF m_point1;
    QPointF m_point2;
    QPointF m_tempPoint;
    QPoint temp;
    QPointF m_pressedPos; // Position where mouse was pressed
    QPointF m_releasedPos; // Position where mouse was released
    QGraphicsScene* scene;
    QGraphicsItem* m_currentItem;
    QGraphicsEllipseItem* m_circle;
    QGraphicsRectItem* m_rectangle;
    QGraphicsLineItem* m_line;
    QVector<QPointF> m_polygon;
    QVector<QPointF> m_path;
    QGraphicsLineItem* m_pathLine;
    QLineF line;
    Layer::LayerType m_layerType = Layer::LayerType::M1;
    Shapes::ShapeType m_shapeType = Shapes::ShapeType::Rectangle;

    QPointF point1;
    QPointF point2;
    QPointF point3;
    QPointF point4;
    int m;
};

#endif // ITEMVIEW_H
