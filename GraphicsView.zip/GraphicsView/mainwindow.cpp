#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "CustomWidgets.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    auto itemView = new ItemView;
    setCentralWidget(itemView);

    createLayoutForLayers(itemView);
    createLayoutForShapes(itemView);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::createLayoutForLayers(ItemView* itemView)
{
    QString icon_abs_path = ":/images/Blue_black.png";
    auto layer1 = new Layer::LayerCell("MET_1", icon_abs_path, Layer::LayerType::M1);
    icon_abs_path = ":/images/GreenDashes_black.png";
    auto layer2 = new Layer::LayerCell("P_DIFF+", icon_abs_path, Layer::LayerType::M2);
    icon_abs_path = ":/images/Red_black.png";
    auto layer3 = new Layer::LayerCell("POLY", icon_abs_path, Layer::LayerType::M3);
    icon_abs_path = ":/images/CyanCrossPattern_black.png";
    auto layer4 = new Layer::LayerCell("CONTACT", icon_abs_path, Layer::LayerType::M4);
    icon_abs_path = ":/images/Magenta_black.png";
    auto layer5 = new Layer::LayerCell("NWELL", icon_abs_path, Layer::LayerType::M5);
    icon_abs_path = ":/images/P_Diff_2.png";
    auto layer6 = new Layer::LayerCell("P_DIFF_2", icon_abs_path, Layer::LayerType::M5);
    icon_abs_path = ":/images/Met4.png";
    auto layer7 = new Layer::LayerCell("MET4", icon_abs_path, Layer::LayerType::M5);
    icon_abs_path = ":/images/NWELL_2.png";
    auto layer8 = new Layer::LayerCell("NWELL_2", icon_abs_path, Layer::LayerType::M5);
    icon_abs_path = ":/images/N_Diff_2.png";
    auto layer9 = new Layer::LayerCell("N_DIFF_2", icon_abs_path, Layer::LayerType::M5);
    icon_abs_path = ":/images/Via1.png";
    auto layer10 = new Layer::LayerCell("VIA_1", icon_abs_path, Layer::LayerType::M5);
    icon_abs_path = ":/images/Via2.png";
    auto layer11 = new Layer::LayerCell("VIA_2", icon_abs_path, Layer::LayerType::M5);
    icon_abs_path = ":/images/Poly2.png";
    auto layer12 = new Layer::LayerCell("POLY_2", icon_abs_path, Layer::LayerType::M5);
    icon_abs_path = ":/images/Met3.png";
    auto layer13 = new Layer::LayerCell("MET_3", icon_abs_path, Layer::LayerType::M5);

    auto layout = new QVBoxLayout;
    layout->addWidget(layer1);
    layout->addWidget(layer2);
    layout->addWidget(layer3);
    layout->addWidget(layer4);
    layout->addWidget(layer5);
    layout->addWidget(layer6);
    layout->addWidget(layer7);
    layout->addWidget(layer8);
    layout->addWidget(layer9);
    layout->addWidget(layer10);
    layout->addWidget(layer11);
    layout->addWidget(layer12);
    layout->addWidget(layer13);

    auto bw = new QWidget;
    bw->setLayout(layout);

    auto wb = new QDockWidget(this);
    wb->setWidget(bw);
    wb->setWindowTitle("Layer ToolBar");

    addDockWidget(Qt::LeftDockWidgetArea, wb);

    connect(layer1, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer2, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer3, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer4, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer5, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer6, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer7, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer8, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer9, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer10, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer11, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer12, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
    connect(layer13, &Layer::LayerCell::sendSignalLT, itemView, &ItemView::recieveLayerType);
}

void MainWindow::createLayoutForShapes(ItemView* itemView)
{
    QString path;
    path = ":/images/rect_30_30_red__transparent_background_8.png";
    auto button1 = new Shapes::Shape(path, Shapes::ShapeType::Rectangle);
    path = ":/images/Line_corerct.png";
    auto button2 = new Shapes::Shape(path, Shapes::ShapeType::Line);
    path = ":/images/Elipse_30_30__3.png";
    auto button3 = new Shapes::Shape(path, Shapes::ShapeType::Circle);
    path = ":/images/Polygon_30_30_2.png";
    auto button4 = new Shapes::Shape(path, Shapes::ShapeType::Polygon);
    path = ":/images/Path_30_30__middle_line_10.png";
    auto button5 = new Shapes::Shape(path, Shapes::ShapeType::Path);
    path = ":/images/T_icon_lightness_minus60_color_red.png";
    auto button6 = new Shapes::Shape(path, Shapes::ShapeType::Path);
    path = ":/images/Move_30_30_3.png";
    auto button7 = new Shapes::Shape(path, Shapes::ShapeType::Path);

    auto layout = new QHBoxLayout;
    layout->addWidget(button1);
    layout->addWidget(button2);
    layout->addWidget(button3);
    layout->addWidget(button4);
    layout->addWidget(button5);
    layout->addWidget(button6);
    layout->addWidget(button7);

    auto bw = new QWidget;
    bw->setLayout(layout);

    auto wb = new QDockWidget(this);
    wb->setWidget(bw);
    wb->setWindowTitle("Shape ToolBar");

    addDockWidget(Qt::TopDockWidgetArea, wb);

    connect(button1, &Shapes::Shape::sendSignalSHT, itemView, &ItemView::recieveShapeType);
    connect(button2, &Shapes::Shape::sendSignalSHT, itemView, &ItemView::recieveShapeType);
    connect(button3, &Shapes::Shape::sendSignalSHT, itemView, &ItemView::recieveShapeType);
    connect(button4, &Shapes::Shape::sendSignalSHT, itemView, &ItemView::recieveShapeType);
    connect(button5, &Shapes::Shape::sendSignalSHT, itemView, &ItemView::recieveShapeType);
    connect(button6, &Shapes::Shape::sendSignalSHT, itemView, &ItemView::recieveShapeType);
    connect(button7, &Shapes::Shape::sendSignalSHT, itemView, &ItemView::recieveShapeType);
}


