#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "CustomWidgets.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    auto itemView = new ItemView;
    setCentralWidget(itemView);

    createLayoutForLayers(itemView);
    createLayoutForShapes(itemView);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::createLayoutForLayers(ItemView* itemView)
{
    QString icon_abs_path = ":/images/Blue_31_30_trial.png";
    auto layer1 = new Layer::LayerCell("M1", icon_abs_path, Layer::LayerType::M1);
    icon_abs_path = ":/images/GreenDashes.png";
    auto layer2 = new Layer::LayerCell("M2", icon_abs_path, Layer::LayerType::M2);
    icon_abs_path = ":/images/Red.png";
    auto layer3 = new Layer::LayerCell("M3", icon_abs_path, Layer::LayerType::M3);
    icon_abs_path = ":/images/CyanCrossPattern.png";
    auto layer4 = new Layer::LayerCell("M4", icon_abs_path, Layer::LayerType::M4);
    icon_abs_path = ":/images/MagentaDashes.png";
    auto layer5 = new Layer::LayerCell("M5", icon_abs_path, Layer::LayerType::M5);

    auto layout = new QVBoxLayout;
    layout->addWidget(layer1);
    layout->addWidget(layer2);
    layout->addWidget(layer3);
    layout->addWidget(layer4);
    layout->addWidget(layer5);

    auto bw = new QWidget;
    bw->setLayout(layout);

    auto wb = new QDockWidget(this);
    wb->setWidget(bw);

    addDockWidget(Qt::LeftDockWidgetArea, wb);

    connect(layer1, &Layer::LayerCell::sendSignalLT,
            itemView, &ItemView::recieveLayerType);
    connect(layer2, &Layer::LayerCell::sendSignalLT,
            itemView, &ItemView::recieveLayerType);
    connect(layer3, &Layer::LayerCell::sendSignalLT,
            itemView, &ItemView::recieveLayerType);
    connect(layer4, &Layer::LayerCell::sendSignalLT,
            itemView, &ItemView::recieveLayerType);
    connect(layer5, &Layer::LayerCell::sendSignalLT,
            itemView, &ItemView::recieveLayerType);
}

void MainWindow::createLayoutForShapes(ItemView* itemView)
{
    QString path;
    path = ":/images/rect_30_30_red__transparent_background_8.png";
    auto button1 = new Shapes::Shape(path, Shapes::ShapeType::Rectangle);
    path = ":/images/Line_corerct.png";
    auto button2 = new Shapes::Shape(path, Shapes::ShapeType::Line);
    path = ":/images/Elipse_30_30__3.png";
    auto button3 = new Shapes::Shape(path, Shapes::ShapeType::Circle);
    path = ":/images/Polygon_30_30_2.png";
    auto button4 = new Shapes::Shape(path, Shapes::ShapeType::Polygon);
    path = ":/images/Path_30_30__middle_line_10.png";
    auto button5 = new Shapes::Shape(path, Shapes::ShapeType::Path);
    path = ":/images/T_icon_lightness_minus60_color_red.png";
    auto button6 = new Shapes::Shape(path, Shapes::ShapeType::Path);
    path = ":/images/Move_30_30_3.png";
    auto button7 = new Shapes::Shape(path, Shapes::ShapeType::Path);

    auto layout = new QVBoxLayout;
    layout->addWidget(button1);
    layout->addWidget(button2);
    layout->addWidget(button3);
    layout->addWidget(button4);
    layout->addWidget(button5);
    layout->addWidget(button6);
    layout->addWidget(button7);

    auto bw = new QWidget;
    bw->setLayout(layout);

    auto wb = new QDockWidget(this);
    wb->setWidget(bw);

    addDockWidget(Qt::RightDockWidgetArea, wb);

    connect(button1, &Shapes::Shape::sendSignalSHT,
            itemView, &ItemView::recieveShapeType);
    connect(button2, &Shapes::Shape::sendSignalSHT,
            itemView, &ItemView::recieveShapeType);
    connect(button3, &Shapes::Shape::sendSignalSHT,
            itemView, &ItemView::recieveShapeType);
    connect(button4, &Shapes::Shape::sendSignalSHT,
            itemView, &ItemView::recieveShapeType);
    connect(button5, &Shapes::Shape::sendSignalSHT,
            itemView, &ItemView::recieveShapeType);
    connect(button6, &Shapes::Shape::sendSignalSHT,
            itemView, &ItemView::recieveShapeType);
    connect(button7, &Shapes::Shape::sendSignalSHT,
            itemView, &ItemView::recieveShapeType);
}


